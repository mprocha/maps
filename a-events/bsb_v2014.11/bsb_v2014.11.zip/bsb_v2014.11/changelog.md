
## 2014.11
- add bsb2014.11* files
- correct the **BR_proxy** Mw(M) application rules. (2015.03)
- add 2 python notebooks to produce both previous formats (2015.03)
- remove previous Mw_MMDDHH extension (2015.03)
- Give 2 Mw values, from Scordillis and Assumpção&Drouet (Unpublished), and a uncertanty value. (Mw extension)
- Add 1's to Months and days with NO values, and 0's to Hour and Minutes in the same condition. (Mw_MMDDHH extension)


## 2014.06
- CLEAN version, now goes up to mag=2.0 instead of mag=2.8 on the last version. 


## pre_2014.06

- catalogo_BR_2013Aug10.dat changed to catalogue_br_RAW.dat

- catalogo_BR_1560a2012_v2013Aug10.csv changed to catalogue_br_FULL.csv

- catalogo_BR_select_1744a2012_mag2.8_v2013Aug10.csv changed to catalogue_br_CLEAN.csv


## 2013.08 (start versioning)
as it
